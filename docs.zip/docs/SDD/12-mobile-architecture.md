# SDD-12 — Arsitektur Mobile

**Area:** `MOB` · **Status:** Draft · **Basis:** [`mobile-requirements.md`](../PRD/05-mobile/mobile-requirements.md)

---

## 1. Konteks

| Kelompok | ID |
|---|---|
| Kebijakan luring | `MOB-OFF-01` … `MOB-OFF-05`, `NO-07` |
| Media & kamera | `MOB-MED-01` … `MOB-MED-07` |
| Versi aplikasi | `MOB-VER-01` … `MOB-VER-05` |
| Deep link | `MOB-DL-01` … `MOB-DL-05` |
| Izin runtime | Bab 32.5 |
| Performa | `MOB-PERF-01` … `MOB-PERF-05`, `NFR-P-10` |
| Keamanan perangkat | `MOB-SEC-01` … `MOB-SEC-06` |
| Distribusi | `MOB-REL-01` … `MOB-REL-06` |
| Alur lapangan | `FR-05.2`, `FR-09.1`, `FR-11.1`, `FR-12.3`, `FR-13.2` |

Basis teknologi ditetapkan Keputusan #3: **React Native** (Android & iOS).

---

## 2. Keputusan Desain

| ID | Keputusan |
|---|---|
| **SDD-MOB-01** | Aplikasi berbagi **paket skema dan peta enum** dengan web ([SDD-FE-05](11-frontend-architecture.md), `SDD-FE-08`); yang tidak dibagi adalah komponen UI. |
| **SDD-MOB-02** | Antrean unggah berkas **dipersistensi ke penyimpanan perangkat**, bukan hanya di memori — satu-satunya state yang bertahan lintas sesi (`MOB-OFF-02`, `MOB-SEC-06`). |
| **SDD-MOB-03** | Kompresi foto dilakukan **sebelum masuk antrean**, bukan saat unggah — antrean menyimpan berkas yang sudah kecil (`MOB-MED-01`). |
| **SDD-MOB-04** | Unggah memakai **presigned URL langsung ke object storage** ([SDD-09 §4.2](09-file-storage-design.md)); antrean menyimpan `file_id` hasil presign, bukan URL-nya. |
| **SDD-MOB-05** | Gerbang versi paksa dipasang sebagai **interceptor global**; `426` memicu layar yang tidak dapat dilewati (`MOB-VER-03`). |
| **SDD-MOB-06** | Pemindaian opname mengirim hasil **per pemindaian**, bukan menumpuk sampai akhir sesi (`MOB-PERF-03`). |
| **SDD-MOB-07** | Aksi yang mengubah data **gagal eksplisit** saat luring — tidak pernah diantrekan (`MOB-OFF-05`). |
| **SDD-MOB-08** | Token disimpan di Keychain/Keystore melalui satu modul `SecureStore`; tidak ada jalur lain yang boleh menulis token. |
| **SDD-MOB-09** | Refresh token diserialisasi dengan *mutex* pada interceptor, sama alasannya dengan web (`SDD-FE-07`). |

---

## 3. Alasan

**SDD-MOB-02/03 — antrean menyimpan berkas terkompresi.** Ini menyelesaikan masalah nyata di lapangan: lima foto tiket kerusakan (`FR-11.1`) dari kamera ponsel modern bisa mencapai 20 MB. Mengompresinya lebih dulu (`MOB-MED-01`: sisi terpanjang 1600 px, ≤ 500 KB) menurunkan itu menjadi ≈ 2,5 MB — perbedaan antara unggahan yang selesai di jaringan sekolah dan yang tidak. Menyimpan berkas mentah di antrean juga akan menghabiskan penyimpanan perangkat teknisi dalam sehari.

**SDD-MOB-04 — antrean menyimpan `file_id`, bukan URL.** URL presign berumur pendek (300 detik). Bila antrean menyimpan URL dan perangkat luring selama sepuluh menit, seluruh antrean kedaluwarsa. Menyimpan `file_id` berarti antrean meminta URL baru saat benar-benar akan mengunggah.

**SDD-MOB-06 — kirim per pemindaian.** Sesi opname bisa mencakup ribuan unit dan berlangsung berjam-jam. Menahan hasil di perangkat sampai akhir sesi berarti aplikasi yang tertutup atau baterai habis menghapus setengah hari kerja. Mengirim per pemindaian juga membuat progres real-time (`FR-13.2 AC`) benar-benar mungkin.

**SDD-MOB-07 — gagal eksplisit, bukan diantrekan.** Ini penegasan `NO-07`. Menyetujui pengajuan atau mencatat serah terima saat luring lalu "menyinkronkan nanti" akan menghasilkan keputusan berdasarkan data basi — persis kelas masalah yang keputusan online-only hindari. Kegagalan yang jelas lebih baik daripada keberhasilan palsu.

---

## 4. Rancangan

### 4.1 Struktur

```
src/
├── app/                 # navigasi, provider, gerbang versi & sesi
├── shared/
│   ├── api/             # klien, interceptor, refresh mutex (SDD-MOB-09)
│   ├── secure/          # SecureStore — satu-satunya penulis token (SDD-MOB-08)
│   ├── upload/          # antrean unggah persisten (SDD-MOB-02)
│   ├── camera/          # pemindai QR + kompresi foto (SDD-MOB-03)
│   ├── schemas/         # dibagi dengan web (SDD-MOB-01)
│   └── enums/           # dibagi dengan web
└── features/
    ├── scan/            # FR-05.2 — titik masuk aksi kontekstual
    ├── loans/           # FR-09.1, FR-09.2
    ├── damage/          # FR-11.1
    ├── workorders/      # FR-12.3
    ├── stocktake/       # FR-13.2
    ├── approvals/       # FR-10.2 dari ponsel
    └── notifications/   # FCM + deep link
```

Aplikasi mobile **tidak** mencerminkan seluruh 21 modul — hanya alur yang PRD nyatakan harus berjalan di lapangan.

### 4.2 Antrean unggah

```
enqueue(localUri, ownerType, ownerId?):
   1. kompres (1600 px, JPEG 80%, EXIF dibuang kecuali orientasi)  MOB-MED-01/02
   2. simpan berkas terkompresi ke direktori antrean perangkat
   3. tulis baris antrean { id, path, ownerType, ownerId, attempts, createdAt }

drain():                                    # dipicu: online kembali, app foreground, timer
   untuk tiap baris (FIFO):
      POST /files/presign  →  { upload_url, file_id }
      PUT langsung ke object storage
      POST /files/confirm  { file_id, checksum }
      tautkan ke entitas bila ownerId sudah ada
      hapus baris + berkas lokal

kebijakan:
   maksimum 72 jam atau 50 berkas; melewati itu → buang tertua + beri tahu   MOB-OFF-03
   percobaan ulang: exponential backoff, tanpa batas selama dalam masa 72 jam
```

Entitas yang fotonya masih tertunda ditandai jelas di UI ("Foto belum terunggah") dan muncul pada daftar tindak lanjut Petugas Sarpras (`MOB-OFF-04`).

### 4.3 Kamera & pemindaian

| Aspek | Implementasi |
|---|---|
| Pemindai QR | Pustaka kamera native; bukan pemindai berbasis WebView |
| Mode beruntun | Kamera tetap aktif; hasil ditambahkan ke daftar tanpa menutup pemindai (`MOB-MED-07`) |
| Jalur cadangan | Tombol "Masukkan kode barang manual" **selalu terlihat**, bukan tersembunyi di menu (`FR-05.2 A1`) |
| Izin ditolak | Panduan mengaktifkan + input manual, bukan layar buntu (`MOB-MED-06`) |
| Kompresi | Dilakukan di *worker thread*; UI tidak membeku saat memproses 5 foto |

### 4.4 Deep link

```
Android App Links   : assetlinks.json     di https://{domain}/.well-known/
iOS Universal Links : apple-app-site-association  di lokasi yang sama
Pola                : https://{domain}/{path}  →  route aplikasi yang sama dengan web
```

| Kasus | Perilaku |
|---|---|
| Objek tidak dapat diakses | Layar "tanpa hak akses", bukan galat mentah (`MOB-DL-03`) |
| Objek sudah dihapus/dibatalkan | "Data tidak lagi tersedia" (`MOB-DL-04`, `FR-17.1 A1`) |
| QR dipindai kamera bawaan | Membuka halaman publik; bila aplikasi terpasang, App/Universal Link mengalihkan ke aplikasi (`MOB-DL-05`) |
| Belum login | Simpan tujuan, arahkan ke login, lanjutkan setelah berhasil |

### 4.5 Gerbang startup

```
1. cek versi   → GET /health atau header X-App-Version pada permintaan pertama
                 426 UPGRADE_REQUIRED → layar pembaruan paksa (MOB-VER-03)
2. cek sesi    → token di SecureStore valid?
3. must_change_password → arahkan ke ganti password (FR-01.1 A4)
4. 2FA belum terverifikasi → arahkan ke verifikasi (BR-070)
5. daftarkan token FCM
6. masuk ke dashboard sesuai role
```

Urutan ini mencerminkan gerbang middleware server (`SDD-AUTH-09`) sehingga klien tidak pernah menampilkan layar yang akan ditolak server.

### 4.6 Keamanan perangkat

| Requirement | Implementasi |
|---|---|
| `MOB-SEC-01` | Token hanya via `SecureStore` (Keychain/Keystore) |
| `MOB-SEC-02` | *Certificate pinning* terhadap domain API |
| `MOB-SEC-03` | Deteksi root/jailbreak; peringatan dapat dilewati hanya pada build uji |
| `MOB-SEC-04` | Layar berdata pribadi disembunyikan di *app switcher* |
| `MOB-SEC-05` | Token FCM dicabut saat logout |
| `MOB-SEC-06` | Tidak ada data operasional tersimpan permanen selain antrean unggah & token |

### 4.7 Performa

| Target | Cara |
|---|---|
| Cold start ≤ 3 detik (`MOB-PERF-01`) | Bundel minimal di layar pertama; fitur berat dimuat malas |
| Opname (`MOB-PERF-02`) | Daftar target dimuat **per lokasi**, `per_page` hingga 500 |
| Daftar panjang (`MOB-PERF-04`) | *Virtualized list*; gambar memakai `thumb` |
| Ukuran unduh ≤ 40 MB (`MOB-PERF-05`) | Aset gambar dioptimalkan; font dibatasi |

---

## 5. Konsekuensi

- Sekolah wajib memiliki domain HTTPS sendiri (`AS-15b`) — App/Universal Links tidak dapat diverifikasi tanpa itu.
- Akun Google Play dan Apple Developer berbayar menjadi prasyarat rilis (`MOB-REL-01`, `AS-15a`), dan kepemilikannya pada sekolah, bukan vendor (`MOB-REL-02`).
- Antrean unggah adalah satu-satunya penyimpanan lokal berisi data; ia masuk lingkup perlindungan data (Bab 28) meski berumur pendek.
- Karena aksi tulis gagal eksplisit saat luring, alur lapangan di area tanpa sinyal (gudang) tetap terhambat. Ini konsekuensi `NO-07` yang diterima; `FE-01` menawarkan penyelesaiannya di rilis berikutnya.

---

## 6. Risiko Teknis

| Risiko | Dampak | Mitigasi |
|---|---|---|
| Kompresi menghilangkan detail bukti | Foto kerusakan tidak terbaca | 1600 px terbukti memadai untuk bukti visual; diuji pada foto nyata saat UAT lapangan (`UAT-04`) |
| Antrean membengkak di perangkat teknisi | Penyimpanan penuh | Batas 50 berkas / 72 jam; indikator jumlah tertunda di UI |
| Verifikasi App Links gagal | Deep link membuka browser, bukan aplikasi | Berkas verifikasi diuji sebagai bagian *smoke test* pasca-deploy (`CD-07`) |
| Certificate pinning memutus akses saat sertifikat diperbarui | Aplikasi tidak bisa konek | Pin pada CA, bukan sertifikat daun; prosedur pembaruan didokumentasikan |
| Peninjauan App Store menunda rilis | Jadwal go-live meleset | Diperhitungkan dalam `GL-11`; pengajuan dilakukan lebih awal pada M6 |
| Perangkat kelas bawah (Android 8, RAM 2 GB) | Cold start & kamera lambat | Matriks perangkat uji (Bab 30.6) menyertakan batas bawah, bukan hanya perangkat tim |

---

## 7. Requirement Terkait

`FR-01.1` `FR-05.2` `FR-09.1` `FR-09.2` `FR-11.1` `FR-12.3` `FR-13.2` `FR-10.2` `FR-17.2` ·
`MOB-OFF-01` … `MOB-OFF-05` · `MOB-MED-01` … `MOB-MED-07` · `MOB-VER-01` … `MOB-VER-05` ·
`MOB-DL-01` … `MOB-DL-05` · `MOB-PERF-01` … `MOB-PERF-05` · `MOB-SEC-01` … `MOB-SEC-06` · `MOB-REL-01` … `MOB-REL-06` ·
`NFR-P-10` `NFR-C-03` `NFR-C-04` `NFR-C-05` `NFR-AC-07` · `NO-07` · `AS-15a` `AS-15b` · `GL-11`

---

## 8. TBD

| ID | Pertanyaan |
|---|---|
| **TBD-MOB-A** | Versi React Native dan strategi pembaruan OTA (mis. CodePush) belum ditetapkan. Berdampak pada seberapa cepat perbaikan dapat dikirim tanpa peninjauan store. |
| **TBD-MOB-B** | Apakah aplikasi perlu mendukung tablet secara khusus. `NFR-C-04` hanya menyebut potret dan lanskap terbatas. |
