# SDD-06 — Desain API

**Area:** `API` · **Status:** Draft · **Basis:** [`api-conventions.md`](../PRD/03-architecture/api-conventions.md), [`api-index.md`](../PRD/_generated/api-index.md)

---

## 1. Konteks

| Kelompok | ID |
|---|---|
| Konvensi & kontrak | Bab 17.1 – 17.3, 17.5 |
| Daftar endpoint | 93 endpoint, dimiliki modul masing-masing (bagian 7) |
| Otorisasi | `PM-01` … `PM-04`, `NFR-S-05` |
| Idempotensi | `ID-01` … `ID-05` |
| Performa | `NFR-P-01`, `NFR-P-02` |
| Dokumentasi | `NFR-M-05` |
| Kompatibilitas | `NFR-C-09`, `MOB-VER-01` … `MOB-VER-05` |

---

## 2. Keputusan Desain

| ID | Keputusan |
|---|---|
| **SDD-API-01** | Skema validasi ditulis **sekali** sebagai skema runtime (Zod atau setara) lalu diturunkan menjadi tipe statis **dan** OpenAPI. Tidak ada tiga definisi terpisah. |
| **SDD-API-02** | OpenAPI **digenerate dari kode**, bukan ditulis tangan. Ini satu-satunya cara `NFR-M-05` ("selalu tersinkron") dapat dipenuhi. |
| **SDD-API-03** | Setiap route mendeklarasikan: permission, skema masukan, skema keluaran, kelas rate limit, dan apakah memerlukan `Idempotency-Key`. Kelalaian mendeklarasikan permission = gagal saat startup (`SDD-AUTH-01`). |
| **SDD-API-04** | Controller **tidak** menangani galat. Seluruh galat dilempar sebagai `DomainError` bertipe dan diterjemahkan `ErrorMapper` terpusat ke kode Bab 17.3. |
| **SDD-API-05** | Paginasi memakai **offset** (`page`/`per_page`) sesuai Bab 17.1, bukan cursor. |
| **SDD-API-06** | Parsing `filter[...]` dan `sort` dilakukan *parser* bersama yang hanya menerima field ber-*allow-list* per endpoint. |
| **SDD-API-07** | Serialisasi keluaran melewati *presenter* per entitas yang menerima `AuthContext`, sehingga penyaringan field (`SDD-AUTH-06`) terjadi di satu tempat. |
| **SDD-API-08** | Versi API di path (`/api/v1`). Perubahan tak kompatibel memerlukan `/api/v2`; penambahan field bersifat kompatibel dan tidak menaikkan versi. |
| **SDD-API-09** | Header `X-App-Version` diperiksa *middleware* dan menghasilkan `426 UPGRADE_REQUIRED` bila di bawah versi minimum (`MOB-VER-02`). |
| **SDD-API-10** | Endpoint yang mengembalikan berkas **tidak pernah** menyalurkan byte melalui API; selalu mengembalikan URL bertanda tangan (lihat [SDD-09](09-file-storage-design.md)). |

---

## 3. Alasan

**SDD-API-01/02 — satu sumber skema.** Menulis validasi, tipe TypeScript, dan OpenAPI secara terpisah menjamin ketiganya menyimpang dalam hitungan minggu. `NFR-M-05` menuntut dokumentasi API selalu sinkron dengan implementasi — itu hanya realistis bila dokumentasi diturunkan dari kode yang benar-benar dieksekusi saat memvalidasi permintaan.

**SDD-API-04 — galat terpusat.** Bab 17.3 mendefinisikan katalog kode galat yang tetap. Bila tiap controller memetakan galatnya sendiri, akan muncul respons yang tidak sesuai katalog dan pesan yang membocorkan detail internal — persis yang dilarang `NFR-R-10`. Satu mapper juga membuat pemetaan `SQLSTATE 23P01 → 409` (`CI-04`) berlaku otomatis di seluruh endpoint.

**SDD-API-05 — offset, bukan cursor.** Cursor lebih unggul pada dataset besar, tetapi Bab 17.1 sudah menetapkan kontrak `page`/`per_page` dan UI menuntut nomor halaman serta total (`meta.total_pages`). Pada volume target (≤5.000 aset, ≤150.000 log per tahun) offset dengan indeks yang tepat memenuhi `NFR-P-01`. Mengubahnya akan mengubah kontrak PRD tanpa manfaat nyata.

**SDD-API-06 — allow-list filter.** Meneruskan nama field dari klien langsung ke kueri adalah jalur pintas menuju kebocoran data dan injeksi. Allow-list per endpoint juga membuat OpenAPI dapat mendokumentasikan filter yang tersedia.

**SDD-API-07 — presenter menerima `AuthContext`.** Tanpa ini, penyaringan field finansial (`BR-073`) akan tersebar di banyak controller dan suatu saat terlewat pada endpoint baru. `SEC-T-02` menguji tepat kasus ini.

---

## 4. Rancangan

### 4.1 Bentuk deklarasi route

```ts
export const showAsset = defineRoute({
  method: 'GET',
  path: '/assets/:id',
  permission: 'asset.view',                 // PM-01 — wajib
  rateLimitClass: 'default',                // NFR-S-07
  params: z.object({ id: z.coerce.number().int().positive() }),
  response: AssetDetailSchema,
  handler: async (ctx, { params }) =>
    AssetPresenter.detail(await assetService.findById(ctx.auth, params.id), ctx.auth),
});
```

Registri route dipindai saat *bootstrap* untuk: memvalidasi kelengkapan deklarasi, membangun OpenAPI, dan membangun matriks uji otorisasi (`SEC-T-01`).

### 4.2 Susunan middleware

```
requestId → logger → cors → helmet(header keamanan NFR-S-11)
   → appVersionGate (426)                       MOB-VER-02
   → authenticate (401)
   → mustChangePassword (403)                   FR-01.1 A4
   → twoFactorVerified (401)                    BR-070
   → permission (403)                           PM-02
   → rateLimit(kelas) (429)                     NFR-S-07
   → idempotency (409) — bila route menuntutnya ID-01
   → validate(params, query, body) (400/422)
   → handler
   → presenter(AuthContext)
   → errorMapper
```

Urutan ini tetap dan diuji; menyisipkan sesuatu di tengahnya memerlukan pembaruan berkas ini.

### 4.3 Kontrak respons

Bentuk amplop sudah ditetapkan Bab 17.2 dan tidak diulang di sini. Yang ditetapkan rancangan:

| Aspek | Ketentuan |
|---|---|
| `meta` | Hanya diisi pada daftar terpaginasi; `null` selain itu |
| `X-Request-Id` | Selalu disertakan; sama dengan `request_id` pada galat |
| `X-RateLimit-*` | Selalu disertakan (`NFR-S-07`) |
| Kompresi | gzip/brotli oleh reverse proxy, bukan aplikasi |
| Tanggal | ISO 8601 UTC (`Z`), konversi ke WIB di klien (`NFR-C-10`) |
| Angka uang | String desimal, bukan float, agar presisi tidak hilang di JSON |

### 4.4 Pemetaan galat

```ts
const MAP: Array<[matcher, httpStatus, code]> = [
  [isZodError,                     400, 'INVALID_REQUEST'],
  [isDomainError('BORROWER_BLOCKED'), 422, 'BORROWER_BLOCKED'],
  [isDomainError('DURATION_EXCEEDED'),422, 'DURATION_EXCEEDED'],
  [isPgError('23P01'),             409, 'RESERVATION_CONFLICT'],   // CI-04
  [isPgError('23505'),             409, 'DUPLICATE_CODE'],
  [isDomainError('APPROVAL_ALREADY_DECIDED'), 409, 'APPROVAL_ALREADY_DECIDED'],
  [isDomainError('INVALID_RULE_DEFINITION'),  422, 'INVALID_RULE_DEFINITION'],
  [isAuthError,                    401, 'UNAUTHENTICATED'],
  [isForbidden,                    403, 'FORBIDDEN'],
  [isNotFound,                     404, 'NOT_FOUND'],
  [isLlmUnavailable,               503, 'LLM_UNAVAILABLE'],
  // fallback
  [always,                         500, 'INTERNAL_ERROR'],
];
```

Galat 500 **tidak pernah** menyertakan pesan asli ke klien (`NFR-R-10`); pesan asli hanya masuk log terstruktur bersama `request_id`.

Pemetaan `23P01 → RESERVATION_CONFLICT` disesuaikan menjadi `ASSET_NOT_AVAILABLE` bila `resource_type = 'asset'`, berdasarkan nama constraint yang dilanggar.

### 4.5 Paginasi & filter

```
GET /assets?page=2&per_page=50
            &filter[status]=TERSEDIA&filter[category_id]=7
            &sort=-created_at
```

| Aturan | Nilai |
|---|---|
| `per_page` bawaan / maksimum | 25 / 100 (Bab 17.1) |
| Pengecualian | `GET /audit-sessions/{id}/items` maksimum 500 (`MOB-PERF-02`) |
| `sort` | Awalan `-` = menurun; hanya field ber-allow-list |
| Filter tak dikenal | `400 INVALID_REQUEST`, bukan diabaikan diam-diam |
| `total` | Dihitung `COUNT(*) OVER ()` dalam kueri yang sama, bukan kueri kedua |

### 4.6 Struktur berkas per modul

```
mXX-nama/
├── routes.ts            # defineRoute[] — satu-satunya tempat permission dideklarasikan
├── controllers/         # tipis: orkestrasi, tanpa logika bisnis
├── services/            # logika bisnis + batas transaksi
├── repositories/        # kueri; WAJIB menerima AuthContext (PM-03)
├── schemas/             # Zod: request & response (SDD-API-01)
└── presenters/          # serialisasi + penyaringan field (SDD-API-07)
```

---

## 5. Konsekuensi

- Setiap endpoint baru memerlukan skema Zod; tidak ada jalur "cepat" tanpa validasi.
- OpenAPI menjadi artefak *build*, bukan berkas yang disunting. Dokumentasi di `/api/docs` dibatasi lingkungan non-produksi (Bab 17.1).
- Matriks uji otorisasi (`SEC-T-01`) dapat digenerate dari registri route — jumlah uji tumbuh otomatis mengikuti jumlah endpoint.
- Karena presenter menerima `AuthContext`, seluruh respons wajib melewatinya; mengembalikan objek repository mentah menjadi pelanggaran yang terdeteksi review.

---

## 6. Risiko Teknis

| Risiko | Dampak | Mitigasi |
|---|---|---|
| Offset paginasi melambat pada halaman jauh | Latensi naik pada log berukuran besar | Indeks penunjang; UI membatasi lompatan halaman; volume target masih aman |
| `COUNT(*) OVER ()` mahal pada tabel besar | Latensi daftar naik | Untuk `activity_logs`, hitungan dibatasi (`FR-18.2 A1` sudah mengizinkan pembatasan tampilan) |
| Skema Zod dan tabel menyimpang | Galat runtime | Uji kontrak membandingkan skema respons dengan hasil kueri nyata |
| Endpoint baru lupa `Idempotency-Key` | Duplikasi transaksi | Daftar endpoint transaksional ditetapkan `ID-01`; uji memverifikasi middleware terpasang pada seluruhnya |
| Versi API v2 diperlukan lebih cepat dari dugaan | Beban pemeliharaan ganda | `NFR-C-09` menjamin dukungan 6 bulan; perubahan aditif tidak menaikkan versi |

---

## 7. Requirement Terkait

Bab 17.1 – 17.3, 17.5 · `PM-01` `PM-02` `PM-03` `PM-04` · `ID-01` … `ID-05` · `CI-04` ·
`NFR-P-01` `NFR-P-02` `NFR-M-05` `NFR-R-10` `NFR-S-05` `NFR-S-06` `NFR-S-07` `NFR-S-11` `NFR-C-09` `NFR-C-10` ·
`BR-073` · `MOB-VER-01` … `MOB-VER-05` · `MOB-PERF-02` · `SEC-T-01` `SEC-T-02`

---

## 8. TBD

| ID | Pertanyaan |
|---|---|
| **TBD-API-A** | Pustaka validasi belum ditetapkan (Zod, Valibot, TypeBox). Ketiganya memenuhi SDD-API-01; berdampak pada bentuk kode dan pembangkitan OpenAPI. |
| **TBD-API-B** | Apakah `/api/docs` boleh diaktifkan di produksi dengan proteksi autentikasi, atau tetap dilarang sepenuhnya sebagaimana Bab 17.1 menyiratkan. |
