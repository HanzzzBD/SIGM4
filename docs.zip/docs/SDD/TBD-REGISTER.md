# Register TBD — Keputusan yang Belum Ditetapkan

Berkas ini mengumpulkan seluruh titik dalam SDD yang **memerlukan keputusan** dan sengaja tidak diisi. Tidak ada angka, kebijakan, atau perilaku yang dikarang.

**Status: 34 terbuka · 0 tertutup** — terkumpul dari 17 berkas SDD.

---

## A. Kebijakan produk & lingkup — memblokir penyelesaian SDD

Perlu keputusan pemilik produk. Tidak dapat ditetapkan tim teknis.

| ID | Berkas | Pertanyaan |
|---|---|---|
| **TBD-AVL-B** | [SDD-01](01-availability-concurrency.md) | Endpoint reservasi: tetap satu `/reservations` (M-07 pemilik) atau dipecah `/room-reservations` + `/item-reservations`. Memecahnya mengubah daftar endpoint PRD = perubahan lingkup. |
| **TBD-APR-A** | [SDD-02](02-approval-engine.md) | `fallback_approver` disebut `RE-11` tetapi tidak ada pada skema Lampiran D.5. Field tingkat aturan, atau selalu jatuh ke Administrator tanpa konfigurasi? |
| **TBD-APR-B** | [SDD-02](02-approval-engine.md) | Jam kerja untuk perhitungan SLA: jam operasional sekolah (06.00–18.00) atau jam administratif yang lebih sempit? Menggeser seluruh tenggat dan pengukuran `SC-03`. |
| **TBD-APR-C** | [SDD-02](02-approval-engine.md) | Perilaku bila approver `approver_type='user'` dinonaktifkan setelah instance berjalan. `FR-02.1 A3` mengatur pencegahan, bukan pemulihan. |
| **TBD-NTF-A** | [SDD-08](08-notification-design.md) | Pengelompokan `jenis` untuk preferensi notifikasi (`FR-17.3`) belum ada di PRD. Perlu daftar kelompok yang dilihat pengguna + pemetaan tiap `NT-xx`. |
| **TBD-NTF-B** | [SDD-08](08-notification-design.md) | Apakah notifikasi terarsip (>90 hari) tetap dapat diakses pengguna lewat filter arsip, atau hanya administratif. |
| **TBD-FS-A** | [SDD-09](09-file-storage-design.md) · [SDD-13](13-security-design.md) | Perlakuan foto berwajah saat permintaan penghapusan data (`DP-04`). Pseudonimisasi identitas tidak menghapus wajah pada foto bukti serah terima/kerusakan. Pertahankan sebagai bukti, kaburkan, atau hapus? |
| **TBD-EVT-B** | [SDD-07](07-event-flow.md) · [SDD-15](15-observability-logging.md) | Apakah dead letter memerlukan antarmuka pemrosesan ulang di menu Administrator, atau cukup lewat akses operasional. Berdampak pada lingkup M-20. |
| **TBD-MOB-B** | [SDD-12](12-mobile-architecture.md) | Apakah aplikasi mobile perlu dukungan tablet khusus. `NFR-C-04` hanya menyebut potret dan lanskap terbatas. |
| **TBD-FE-B** | [SDD-11](11-frontend-architecture.md) | Apakah web perlu mode gelap. Tidak disebut PRD; berdampak pada jumlah token warna dan uji kontras. |
| **TBD-SEC-B** | [SDD-13](13-security-design.md) | Apakah sekolah memerlukan kepatuhan formal di luar UU PDP (mis. standar dinas pendidikan setempat). |
| **TBD-AUTH-C** | [SDD-03](03-authorization.md) | Konfirmasi bahwa penambahan mekanisme teknis murni seperti `role_version` boleh diputuskan di tingkat SDD tanpa dianggap perubahan requirement. |

## B. Parameter operasional — sebaiknya ditunda sampai staging berdiri

Menebaknya sekarang tidak menambah nilai; ditetapkan setelah uji beban `NFR-P-09` dan sizing nyata.

| ID | Berkas | Pertanyaan |
|---|---|---|
| **TBD-AVL-A** | [SDD-01](01-availability-concurrency.md) · [SDD-05](05-database-design.md) | Kebijakan arsip/partisi `booking_slots`. Slot `Released` dipertahankan untuk analitik sehingga tabel tumbuh monoton. |
| **TBD-AVL-C** | [SDD-01](01-availability-concurrency.md) · [SDD-14](14-performance-design.md) · [SDD-16](16-infrastructure-deployment.md) | Ukuran connection pool per instance API dan worker. |
| **TBD-AVL-D** | [SDD-01](01-availability-concurrency.md) · [SDD-14](14-performance-design.md) | TTL cache ketersediaan. Rancangan memilih tanpa cache; nilai dalam batas `AV-04` diperlukan bila `AV-03` tidak tercapai. |
| **TBD-AUTH-B** | [SDD-03](03-authorization.md) · [SDD-04](04-authentication-session.md) | Masa tumpang tindih dua kunci Ed25519 saat rotasi 6 bulanan (`SEC-CFG-02`). |
| **TBD-SESS-A** | [SDD-04](04-authentication-session.md) | Masa berlaku *challenge token* 2FA. Rancangan memilih 5 menit; tidak ada angka di PRD. |
| **TBD-EVT-A** | [SDD-07](07-event-flow.md) | Retensi baris `event_outbox` yang sudah diproses. Berkaitan dengan **TBD-AVL-A**. |
| **TBD-FS-B** | [SDD-09](09-file-storage-design.md) | Apakah berkas perlu dipindah ke penyimpanan dingin setelah entitasnya lama tidak aktif. Berkaitan dengan estimasi biaya. |
| **TBD-AI-B** | [SDD-10](10-ai-orchestrator-design.md) | Nilai `effort` produksi untuk chatbot. Rancangan memilih `"low"` demi latensi; keputusan final menunggu hasil eval terhadap `SC-10`. |
| **TBD-AI-C** | [SDD-10](10-ai-orchestrator-design.md) | Ambang biaya harian Claude API yang memicu alarm. Bergantung anggaran sekolah. |
| **TBD-PERF-A** | [SDD-14](14-performance-design.md) | Ambang jumlah kueri per endpoint untuk uji N+1 (`SDD-PERF-02`). Dikalibrasi saat endpoint pertama dibangun. |
| **TBD-INF-A** | [SDD-16](16-infrastructure-deployment.md) | Penyedia infrastruktur. Menentukan sizing dan biaya nyata, serta PostgreSQL terkelola vs dikelola sendiri. |
| **TBD-SEC-A** | [SDD-13](13-security-design.md) | Penyedia penetration test independen dan anggarannya — dependensi jadwal pada `GL-04`. |
| **TBD-OBS-B** | [SDD-15](15-observability-logging.md) | Penerima alarm (*on-call*) dan jalur eskalasi. `OBS-07` mewajibkannya sebelum go-live; keputusan organisasi sekolah. |

## C. Pilihan teknis murni — dapat diputuskan arsitek

Tidak mengubah requirement; hanya bentuk kode dan perkakas.

| ID | Berkas | Pertanyaan |
|---|---|---|
| **TBD-AUTH-A** | [SDD-03](03-authorization.md) · [SDD-04](04-authentication-session.md) | Media penyimpanan daftar refresh token. **SDD-04 merancangnya di PostgreSQL** (pencabutan tidak boleh hilang saat Redis restart) — perlu konfirmasi atau evaluasi ulang. |
| **TBD-DB-A** | [SDD-05](05-database-design.md) · [SDD-16](16-infrastructure-deployment.md) | Alat migration (SQL polos + runner vs perkakas seperti node-pg-migrate). |
| **TBD-API-A** | [SDD-06](06-api-design.md) | Pustaka validasi (Zod, Valibot, TypeBox). Ketiganya memenuhi `SDD-API-01`. |
| **TBD-API-B** | [SDD-06](06-api-design.md) | Apakah `/api/docs` boleh aktif di produksi dengan proteksi autentikasi, atau tetap dilarang sesuai Bab 17.1. |
| **TBD-FE-A** | [SDD-11](11-frontend-architecture.md) | Pustaka server-state dan pustaka komponen dasar. |
| **TBD-MOB-A** | [SDD-12](12-mobile-architecture.md) | Versi React Native dan strategi pembaruan OTA. Berdampak pada kecepatan pengiriman perbaikan tanpa peninjauan store. |
| **TBD-OBS-A** | [SDD-15](15-observability-logging.md) | Perkakas observability (mandiri vs terkelola). Berdampak pada biaya dan beban pemeliharaan sekolah. |
| **TBD-INF-B** | [SDD-16](16-infrastructure-deployment.md) | Orkestrasi: Docker Compose (sesuai `INF-05`) atau Kubernetes bila sekolah sudah memilikinya. |

## D. Konten yang belum final

| ID | Berkas | Pertanyaan |
|---|---|---|
| **TBD-AI-A** | [SDD-10](10-ai-orchestrator-design.md) | Panjang dan isi final prefiks statis system prompt. **Harus ≥ 1.024 token** agar prompt caching aktif pada `claude-sonnet-5` — di bawah itu caching mati tanpa galat. Bila naskah Bab 22.5 lebih pendek, perlu diputuskan: perkaya prefiks, atau lepaskan caching. |

---

## Cara membaca register ini

| Kelompok | Jumlah | Kapan diputuskan |
|---|---|---|
| A — Kebijakan produk | 12 | **Sekarang** — memblokir penyelesaian SDD terkait |
| B — Parameter operasional | 13 | Setelah staging berdiri & uji beban dijalankan |
| C — Pilihan teknis | 8 | Saat modul terkait mulai dibangun |
| D — Konten | 1 | Saat naskah prompt disusun (M5) |

Kelompok B sengaja ditunda: menetapkan ukuran pool koneksi atau TTL cache tanpa data pengukuran hanya memindahkan tebakan ke dokumen. Kelompok A tidak bisa ditunda — SDD yang bersangkutan tidak dapat naik dari Draft tanpa jawabannya.

---

## Tertutup

_Belum ada._

Format saat menutup: pindahkan barisnya ke sini, tambahkan kolom **Keputusan** dan **Tanggal**, lalu perbarui berkas SDD yang bersangkutan.
